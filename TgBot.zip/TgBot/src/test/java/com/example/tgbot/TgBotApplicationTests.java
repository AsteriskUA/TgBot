package com.example.tgbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TgBotApplicationTests {

    @Test
    void contextLoads() {
    }

}
